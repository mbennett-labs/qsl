import React from 'react';
import { Shield, Brain, Database, Lock, ChevronRight, Award, Users, Blocks } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800">
      {/* Hero Section */}
      <header className="relative min-h-screen flex items-center justify-center px-4">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg')] bg-cover bg-center opacity-10"></div>
        <div className="relative max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Advanced Security Solutions for the Quantum Age
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Cybersecurity, Blockchain, and AI expertise to protect and enhance your digital assets
          </p>
          <button className="bg-teal-500 hover:bg-teal-600 text-white px-8 py-3 rounded-lg font-semibold flex items-center mx-auto group">
            Explore Our Services
            <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </header>

      {/* Services Section */}
      <section className="py-20 px-4 bg-gray-900">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Our Key Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Shield, title: 'Security Consulting', desc: 'Comprehensive security assessments and strategic planning' },
              { icon: Blocks, title: 'Blockchain Solutions', desc: 'Smart contracts and decentralized application development' },
              { icon: Brain, title: 'AI Security Integration', desc: 'Intelligent threat detection and prevention systems' },
              { icon: Lock, title: 'Quantum-Resistant Encryption', desc: 'Future-proof encryption solutions' },
            ].map((service, index) => (
              <div key={index} className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors">
                <service.icon className="w-12 h-12 text-teal-500 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
                <p className="text-gray-400">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-20 px-4 bg-gray-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-8">Why Choose Quantum Shield Labs?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center">
              <Award className="w-12 h-12 text-teal-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Expert Team</h3>
              <p className="text-gray-400">Industry-leading expertise in cybersecurity and blockchain</p>
            </div>
            <div className="flex flex-col items-center">
              <Database className="w-12 h-12 text-teal-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Cutting-edge Tech</h3>
              <p className="text-gray-400">Latest security solutions and quantum-resistant systems</p>
            </div>
            <div className="flex flex-col items-center">
              <Users className="w-12 h-12 text-teal-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Client Focus</h3>
              <p className="text-gray-400">Tailored solutions for your specific security needs</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gray-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Ready to secure your digital future?</h2>
          <p className="text-xl text-gray-300 mb-8">Let's discuss how we can protect your assets in the quantum age.</p>
          <button className="bg-teal-500 hover:bg-teal-600 text-white px-8 py-3 rounded-lg font-semibold">
            Contact Us Today
          </button>
        </div>
      </section>
    </div>
  );
}

export default App;